/**
 *Hannah Blair
 * September 13, 2016
 * This program prints out my name and some other info about me.
 */
package mywelcomeworlddisplay2;

public class MyWelcomeWorldDisplay2 {
    
    public static void main(String[] args) {
        
        String greeting1 = "Hannah Blair";
        String greeting2 = "666 Ambrose dr,";
        String greeting3 = "Louisville Ky, 40205";
        String greeting4 = "(502)666-5555";
        String greeting5 = "hannahjaneblair@gmail.com";
        	System.out.println(greeting1);
                System.out.println(greeting2);
                System.out.println(greeting3);
                System.out.println(greeting4);
                System.out.println(greeting5);
              
    }
    
}

