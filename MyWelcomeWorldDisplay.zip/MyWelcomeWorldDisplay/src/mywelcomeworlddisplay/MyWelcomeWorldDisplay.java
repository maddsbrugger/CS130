/**
 *Hannah Blair
 * September 13, 2016
 * This program prints out "My name is Hannah" and "Hello World".
 */
package mywelcomeworlddisplay;

public class MyWelcomeWorldDisplay {
    
    public static void main(String[] args) {
        
        String greeting1 = "My Name is Hannah";
        String greeting2 = "Hello World";

        	System.out.println(greeting1);
                System.out.println(greeting2);
    }
    
}
